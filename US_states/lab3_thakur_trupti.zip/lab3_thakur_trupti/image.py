import inline as inline
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
us_states = [['Maryland', 'Annapolis', 6035802, 'FlowerMDBlack-eyedSusan.jpg'],
             ['California', 'Sacramento', 39461588, 'California Poppy.jpg'],
             ['New York', 'Albany', 19530351, 'redrosebeautystateflowerNY.jpg'],
             ['Alabama', 'Montgomery', 4887681, 'camellia-flower.jpg'],
             ['Alaska', 'Juneau', 735139, 'Forget Me Not'],
             ['Arizona', 'Phoenix', 7158024, 'Saguaro Cactus Blossom'],
             ['Arkansas', 'Little Rock', 3009733, 'Apple Blossom'],
             ['Colorado', 'Denver', 5691287, 'White and Lavender Columbine'],
             ['Connecticut', 'Hartford', 3571520, 'Mountain Laurel'],
             ['Delaware', 'Denver', 965479, 'Peach Blossom'],
             ['Florida', 'Tallahassee', 21244317, 'Orange Blossom'],
             ['Georgia', 'Atlanta', 10511131, 'Cherokee Rose'],
             ['Hawaii', 'Honolulu', 1420593, 'Hibiscus'],
             ['Idaho', 'Boise', 1750536, 'Boise'],
             ['Illinois', 'Springfield', 12723071, 'Purple Violet'],
             ['Indiana', 'Indianapolis', 6695497, 'Peony'],
             ['Iowa', 'Des Moines', 3148618, 'Wild Prairie Rose'],
             ['Kansas', 'Topeka', 2911359, 'Sunflower'],
             ['Kentucky', 'Frankfort', 4461153, 'Goldenrod'],
             ['Louisiana', 'Baton Rouge', 4659690, 'Magnolia'],
             ['Maine', 'Augusta', 1339057, 'White Pine Cone and Tassel'],
             ['Massachusetts', 'Boston', 6882635, 'Mayflower'],
             ['Michigan', 'Lansing', 9984072, 'Apple Blossom'],
             ['Minnesota', 'Saint Paul', 5606249, 'Pink and White Lady Slipper'],
             ['Mississippi', 'Jackson', 2981020, 'Magnolia'],
             ['Missouri', 'Jefferson City', 6121623, 'Bitterroot'],
            ['Montana', 'Helena',1060665, 'Bitterroot'],
             ['Nebraska', 'Lincoln', 1925614, 'Goldenrod'],
             ['Nevada', 'Carson City', 3027341, 'Sagebrush'],
             ['New Hampshire', 'Concord', 1353465, 'Purple Lilac'],
             ['New Jersey', 'Trenton', 8886025, 'Violet'],
             ['New Mexico', 'Santa Fe', 2092741, 'Yucca Flower'],
             ['North Carolina', 'Raleigh', 10381615, 'Dogwood'],
             ['Ohio', 'Columbus', 11676341, 'Scarlet Carnation'],
             ['Oklahoma', 'Oklahoma City', 3940235, 'Mistletoe'],
             ['Oregon', 'Salem', 4181886, 'Oregon Grape'],
             ['Pennsylvania', 'Harrisburg', 12800922, 'Mountain Laurel'],
             ['Rhode Island', 'Providence', 1058287, 'Violet'],
             ['South Carolina', 'Columbia', 5084156, 'Yellow Jessamine'],
             ['North Dakota', 'Bismarck', 758080, 'Wild Prairie Rose'],
             ['South Dakota', 'Pierre', 878698, 'Pasque Flower'],
             ['Tennessee', 'Nashville', 6771631, 'Iris'],
             ['Vermont', 'Montpelier', 624358, 'Red Clover'],
             ['Utah', 'Salt Lake City', 3153550, 'Sego Lily'],
             ['Virginia', 'Richmond', 8501286, 'Dogwood'],
             ['Texas', 'Austin', 28628666, 'Bluebonnet'],
             ['Washington', 'Olympia', 7523869, 'Pink Rhododendron'],
             ['West Virginia', 'Charleston', 1804291, 'Rhododendron'],
             ['Wisconsin', 'Madison', 5807406, 'Wood Violet'],
             ['Wyoming', 'Cheyenne', 577601, 'Indian Paintbrush'],
             ]
state_to_find = 'Maryland'
for state in us_states:
    if state[0] == state_to_find:
        print(f"\n{'State':<15}{'Capital':<15}{'Population':<15}{'State_Flower':<15}")
        print(f'{state[0]:<15} {state[1]:<15}{state[2]:<15} {state[3]:<15}')
        img = mpimg.imread(state[3])
        #print(img)
        #imgplot = plt.imshow(img)
        #print(img.shape)
        # Display image
        fig = plt.figure()
        ax = fig.subplots()
        ax.imshow(img)
        plt.show()
        break

    print("State is not available in list.")



