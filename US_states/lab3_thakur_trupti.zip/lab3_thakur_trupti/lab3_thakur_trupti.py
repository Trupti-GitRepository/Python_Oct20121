# dictionary data-structure was my first choice for this lab.
# values can be store in key-value pair, duplicates  keys are not allowed in dict.
# another data structure is Tuple, but Tuple is not a right choice for this as Tuple is mutable
# list can be easily accessed using index, so I choose multidimentional list for this lab.

""" Menu driven application provides users with the ability to search and display \
U.S. State Capital, population and Flowers."""
import sys

import matplotlib.pyplot as plt
import matplotlib.image as mpimg

# List of all u.s. states, capital, population, flowers
us_states = [['Maryland', 'Annapolis', 6035802, 'FlowerMDBlack-eyedSusan.jpg'],
             ['California', 'Sacramento', 39461588, 'CAflowerCaliforniaPoppy.jpg'],
             ['New York', 'Albany', 19530351, 'redrosebeautystateflowerNY.jpg'],
             ['Alabama', 'Montgomery', 4887681, 'camellia-flower.jpg'],
             ['Alaska', 'Juneau', 735139, 'Alpineforgetmenot.jpg'],
             ['Arizona', 'Phoenix', 7158024, 'saguaroflowersFlickr.jpg'],
             ['Arkansas', 'Little Rock', 3009733, 'AppletreeblossomArkansasflower.jpg'],
             ['Colorado', 'Denver', 5691287, 'Colorado_columbine2.jpg'],
             ['Connecticut', 'Hartford', 3571520, 'Mountain-Laural-flowers2.jpg'],
             ['Delaware', 'Denver', 965479, 'peachblossomspeachflowers.jpg'],
             ['Florida', 'Tallahassee', 21244317, 'OrangeBlossomsFloridaFlower.jpg'],
             ['Georgia', 'Atlanta', 10511131, 'CherokeeRoseFlower.jpg'],
             ['Hawaii', 'Honolulu', 1420593, 'yellowhibiscusPuaAloalo.jpg'],
             ['Idaho', 'Boise', 1750536, 'syringaPhiladelphuslewisiiflower.jpg'],
             ['Illinois', 'Springfield', 12723071, 'singlebluevioletflower.jpg'],
             ['Indiana', 'Indianapolis', 6695497, 'PeonyPaeoniaflowers.jpg'],
             ['Iowa', 'Des Moines', 3148618, 'WildPrairieRose.jpg'],
             ['Kansas', 'Topeka', 2911359, 'native-sunflowers.jpg'],
             ['Kentucky', 'Frankfort', 4461153, 'stateflowergoldenrod-bloom.jpg'],
             ['Louisiana', 'Baton Rouge', 4659690, 'LouisianaIrisWildflower-0.jpg'],
             ['Maine', 'Augusta', 1339057, 'whitepinemalecones.jpg'],
             ['Massachusetts', 'Boston', 6882635, 'MayflowerTrailingArbutus.jpg'],
             ['Michigan', 'Lansing', 9984072, 'appleblossombeauty.jpg'],
             ['Minnesota', 'Saint Paul', 5606249, 'pinkwhiteladysslipperflower1.jpg'],
             ['Mississippi', 'Jackson', 2981020, 'magnoliablossomflower01.jpg'],
             ['Missouri', 'Jefferson City', 6121623, 'hawthornflowersblossoms1.jpg'],
             ['Montana', 'Helena', 1060665, 'bitterrootfloweremblem.jpg'],
             ['Nebraska', 'Lincoln', 1925614, 'goldenrodflowersyellow4.jpg'],
             ['Nevada', 'Carson City', 3027341, 'Nevada-Sagebrush-Artemisia-tridentata.jpg'],
             ['New Hampshire', 'Concord', 1353465, 'NH-pinkLadysSlipperFlower.jpg'],
             ['New Jersey', 'Trenton', 8886025, 'wood-violet.jpg'],
             ['New Mexico', 'Santa Fe', 2092741, 'YuccaFlowersclose.jpg'],
             ['North Carolina', 'Raleigh', 10381615, 'floweringdogwoodflowers2.jpg'],
             ['Ohio', 'Columbus', 11676341, 'WhitetrilliumTrilliumgrandiflorum.jpg'],
             ['Oklahoma', 'Oklahoma City', 3940235, 'mistletoe_phoradendron_serotinum.jpg'],
             ['Oregon', 'Salem', 4181886, 'Oregongrapeflowers2.jpg'],
             ['Pennsylvania', 'Harrisburg', 12800922, 'Mt_Laurel_Kalmia_Latifolia.jpg'],
             ['Rhode Island', 'Providence', 1058287, 'violetsflowers.jpg'],
             ['South Carolina', 'Columbia', 5084156, 'CarolinaYellowJessamine101.jpg'],
             ['North Dakota', 'Bismarck', 758080, 'flowerwildprairierose.jpg'],
             ['South Dakota', 'Pierre', 878698, 'Pasqueflower-03.jpg'],
             ['Tennessee', 'Nashville', 6771631, 'passionflowerwildflower2.jpg'],
             ['Vermont', 'Montpelier', 624358, 'redcloverstateflowerWV.jpg'],
             ['Utah', 'Salt Lake City', 3153550, 'SegoLily.jpg'],
             ['Virginia', 'Richmond', 8501286, 'floweringDogwoodSpring.jpg'],
             ['Texas', 'Austin', 28628666, 'Texas-dawn-waterlily-Nymphaea.jpg'],
             ['Washington', 'Olympia', 7523869, 'flower_rhododendronWeb.jpg'],
             ['West Virginia', 'Charleston', 1804291, 'rhododendronWVstateflower.jpg'],
             ['Wisconsin', 'Madison', 5807406, 'wood-violet.jpg'],
             ['Wyoming', 'Cheyenne', 577601, 'indianpaintbrushWYflower.jpg']
             ]


def show_menu_options():
    """ Display menu options for the State Capital and Flower List application"""
    print("\nPlease see the below menu options.")
    print("\n1.Display all U.S.States information in alphabetical order. "
          "\n2.Search for the states."
          "\n3.Bar Graph of the top 5 populated states."
          "\n4.Update the state population for a specific state."
          "\n5.Exit the program.")


def sorted_states(items):
    """ Display states information in alphabetical order"""
    print(f"\n{'State':<15}{'Capital':<15}{'Population':<15}{'State_Flower':<15}\n")
    for state in sorted(items):
        print(f'{state[0]:<15} {state[1]:<15}{state[2]:<15} {state[3]:<15}')


# def plot_graph(index):
#     img = mpimg.imread(state[3])
#     # print(img)
#     plt.imshow(img)


def search_state(state_to_find):
    """ Display searched state information """
    for state in us_states:
        if state[0] == state_to_find:
            print(f'{state[0]:<15} {state[1]:<15}{state[2]:<15} {state[3]:<15}')
            img = mpimg.imread(state[3])
            # print(img)
            plt.imshow(img)

            # Display image
            #     fig = plt.figure()
            #     ax = fig.subplots()
            #     ax.imshow(img)
            #     plt.show()
            #     break


def populated_states_barGraph():
    """ Display Bar graph for top five populated states."""
    # sorting list on population
    us_states.sort(key=lambda x: x[2], reverse=True)  # x[2] indicates column 3 as index, population
    # print("sorted states based on population",us_states)
    top_populated_states = us_states[0:5]
    # print("top_populated_states", top_populated_states)
    state_list = [x[0] for x in top_populated_states]
    print("\npopulated state list:", state_list)
    top_population = [x[2] for x in top_populated_states]
    print("\ntop_population:", top_population)

    # creating bar graph
    plt.bar(state_list, top_population)
    plt.title('Top populated states')
    plt.xlabel('States')
    plt.ylabel('Population')
    print("Close the graph to continue......")
    plt.show()


def update_population(state_to_find, population):
    """ Update population for searched state and display updated information """
    for state in us_states:
        if state[0] == state_to_find:
            state[2] = population
            print("Updated population information.")
            print(f"\n{'State':<15}{'Capital':<19}{'Population':<15}{'State_Flower':<15}")
            print(f'{state[0]:<15} {state[1]:<19}{state[2]:<15} {state[3]:<15}')


def main():
    print("\n*** Welcome to U.S State, Capital and Flower List application.***")
    reply = input("\nDo you want to use application? Y/ N: ").lower()
    while reply == 'y' or reply == 'yes':
        show_menu_options()
        try:
            choice = int(input("\nEnter your choice[ 1, 2, 3, 4, 5 ].: "))
        except ValueError:
            print("Not an integer! Try again")
            continue
        else:
            if choice == 1:
                print("\nHere is the information of U.S.States in alphabetical order."
                      "(State, Capitals,Population,Flower.)")
                sorted_states(us_states)

            elif choice == 2:
                found = False
                while not found:
                    state = input("Please enter the full state name :  ").capitalize()
                    if not state.isalpha():
                        print("Please check name. Full valid state name is required.")
                        continue
                    elif len(state) <= 2:
                        print("Please check name. Full valid state name is required.")
                        continue
                    else:
                        try:
                            search_state(state)
                            break
                        except NameError:
                            print("Image for the state flower is not loading....Please try after some time ")
                            break

            elif choice == 3:
                flag = False
                while not flag:
                    try:
                        print("Here is the bar graph of 5 populated states.")
                        populated_states_barGraph()
                        flag = True

                    except NameError:
                        print("Graph is not available currently...... Please try after some time...")

            elif choice == 4:
                found = False
                while not found:
                    state = input("Enter full state name: ").capitalize()
                    if not state.isalpha():
                        print("Please check name. Full valid state name is required.")
                        continue
                    elif len(state) <= 2:
                        print("Please check name. Full state name is required.")
                        continue

                    else:
                        try:
                            population = int(input("Enter population."))
                        except ValueError:
                            print("Please enter a whole number without comma.")
                        else:
                            try:
                                update_population(state, population)
                                found = True
                            except ValueError:
                                print("Please check the state name.")

            elif choice == 5:
                print("Thank you for using State, Capital and Flower List application.")
                sys.exit(0)
            else:
                print("Invalid choice.")
                reply = input("\nDo you want to select another option? Y/ N: ").lower()
                if reply == 'y' or reply == 'yes':
                    continue
                else:
                    print("Thank you for visiting U.S. State Capital and Flower List application.")


main()
